"use client"

import { useState, useEffect } from "react"

const FamilyMemberForm = ({ member, onSave, onCancel, onDelete, isNew = false }) => {
  const [fullName, setFullName] = useState(member?.fullName || "")
  const [age, setAge] = useState(member?.age || "")
  const [gender, setGender] = useState(member?.gender || "")
  const [medicalConditions, setMedicalConditions] = useState(member?.medicalConditions || [])
  const [otherMedicalCondition, setOtherMedicalCondition] = useState(member?.otherMedicalCondition || "")
  const [role, setRole] = useState(member?.role || [])
  const [otherRole, setOtherRole] = useState(member?.otherRole || "")
  const [email, setEmail] = useState(member?.email || "")
  const [profilePic, setProfilePic] = useState(member?.profilePic || null)
  const [profilePicPreview, setProfilePicPreview] = useState(member?.profilePic || "")
  const [loading, setLoading] = useState(false)
  const [errors, setErrors] = useState({})

  const medicalConditionsList = [
    "Diabète",
    "Hypertension",
    "Maladie cœliaque",
    "Allergie aux arachides",
    "Intolérance au lactose",
    "Végétarien",
    "Végétalien",
    "Aucun",
  ]

  const familyRoles = ["Mère", "Père", "Enfant", "Grand-parent", "Conjoint(e)", "Frère/Sœur"]

  const isEmailDisabled = Number.parseInt(age) < 5

  useEffect(() => {
    if (member) {
      setFullName(member.fullName || "")
      setAge(member.age || "")
      setGender(member.gender || "")
      setMedicalConditions(member.medicalConditions || [])
      setOtherMedicalCondition(member.otherMedicalCondition || "")
      setRole(member.role || [])
      setOtherRole(member.otherRole || "")
      setEmail(member.email || "")
      setProfilePic(member.profilePic || null)
      setProfilePicPreview(member.profilePic || "")
    }
  }, [member])

  const validateForm = () => {
    const newErrors = {}

    if (!fullName.trim()) {
      newErrors.fullName = "Le nom est requis"
    }
    if (!age || age < 0) {
      newErrors.age = "L'âge est requis et doit être positif"
    }
    if (!gender) {
      newErrors.gender = "Le sexe est requis"
    }
    if (role.length === 0) {
      newErrors.role = "Au moins un rôle est requis"
    }
    if (!isEmailDisabled && email && !/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = "Email invalide"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleMedicalConditionChange = (e) => {
    const { value, checked } = e.target
    if (checked) {
      setMedicalConditions([...medicalConditions, value])
    } else {
      setMedicalConditions(medicalConditions.filter((condition) => condition !== value))
    }
  }

  const handleRoleChange = (e) => {
    const { value, checked } = e.target
    if (checked) {
      setRole([...role, value])
    } else {
      setRole(role.filter((r) => r !== value))
    }
  }

  const handleProfilePicChange = (e) => {
    const file = e.target.files[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setProfilePic(reader.result)
        setProfilePicPreview(reader.result)
      }
      reader.readAsDataURL(file)
    } else {
      setProfilePic(null)
      setProfilePicPreview("")
    }
  }

  const handleSave = async (e) => {
    e.preventDefault()

    if (!validateForm()) return

    setLoading(true)

    const memberData = {
      ...(isNew ? {} : { id: member?.id }),
      fullName,
      age: Number.parseInt(age),
      gender,
      email: isEmailDisabled ? "" : email,
      medicalConditions: medicalConditions.includes("Autres")
        ? [...medicalConditions.filter((c) => c !== "Autres"), otherMedicalCondition]
        : medicalConditions,
      role: role.includes("Autres") ? [...role.filter((r) => r !== "Autres"), otherRole] : role,
      profilePic: profilePic || "",
    }

    if (medicalConditions.includes("Autres") && otherMedicalCondition) {
      memberData.otherMedicalCondition = otherMedicalCondition
    }

    if (role.includes("Autres") && otherRole) {
      memberData.otherRole = otherRole
    }

    try {
      await onSave(memberData)
    } catch (error) {
      console.error("Erreur lors de la sauvegarde:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async () => {
    if (onDelete && member?.id && window.confirm("Êtes-vous sûr de vouloir supprimer ce membre ?")) {
      setLoading(true)
      try {
        await onDelete(member.id)
      } catch (error) {
        console.error("Erreur lors de la suppression:", error)
      } finally {
        setLoading(false)
      }
    }
  }

  return (
    <div className="card glass-effect fade-in">
      <div className="card-header">
        <h4 className="mb-0">
          <i className="fas fa-user-plus me-2"></i>
          {isNew ? "Ajouter un Membre de la Famille" : "Modifier le Membre de la Famille"}
        </h4>
      </div>
      <div className="card-body">
        <form onSubmit={handleSave}>
          <div className="row">
            <div className="col-md-6">
              <div className="form-group">
                <label htmlFor="memberFullName" className="form-label">
                  <i className="fas fa-user me-1"></i>
                  Nom Complet *
                </label>
                <input
                  type="text"
                  className={`form-control ${errors.fullName ? "is-invalid" : fullName ? "is-valid" : ""}`}
                  id="memberFullName"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  required
                  disabled={loading}
                />
                {errors.fullName && <div className="invalid-feedback">{errors.fullName}</div>}
                {fullName && !errors.fullName && (
                  <div className="validation-icon text-success">
                    <i className="fas fa-check"></i>
                  </div>
                )}
              </div>
            </div>

            <div className="col-md-6">
              <div className="form-group">
                <label htmlFor="memberAge" className="form-label">
                  <i className="fas fa-birthday-cake me-1"></i>
                  Âge *
                </label>
                <input
                  type="number"
                  className={`form-control ${errors.age ? "is-invalid" : age ? "is-valid" : ""}`}
                  id="memberAge"
                  value={age}
                  onChange={(e) => setAge(e.target.value)}
                  min="0"
                  required
                  disabled={loading}
                />
                {errors.age && <div className="invalid-feedback">{errors.age}</div>}
              </div>
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">
              <i className="fas fa-venus-mars me-1"></i>
              Sexe *
            </label>
            <div className="d-flex gap-4 mt-2">
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="radio"
                  value="Homme"
                  checked={gender === "Homme"}
                  onChange={(e) => setGender(e.target.value)}
                  required
                  disabled={loading}
                  id="homme"
                />
                <label className="form-check-label" htmlFor="homme">
                  <i className="fas fa-mars me-1"></i>
                  Homme
                </label>
              </div>
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="radio"
                  value="Femme"
                  checked={gender === "Femme"}
                  onChange={(e) => setGender(e.target.value)}
                  required
                  disabled={loading}
                  id="femme"
                />
                <label className="form-check-label" htmlFor="femme">
                  <i className="fas fa-venus me-1"></i>
                  Femme
                </label>
              </div>
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="radio"
                  value="Autre"
                  checked={gender === "Autre"}
                  onChange={(e) => setGender(e.target.value)}
                  disabled={loading}
                  id="autre"
                />
                <label className="form-check-label" htmlFor="autre">
                  <i className="fas fa-genderless me-1"></i>
                  Autre
                </label>
              </div>
            </div>
            {errors.gender && <div className="text-danger small mt-1">{errors.gender}</div>}
          </div>

          <div className="form-group">
            <label className="form-label">
              <i className="fas fa-heartbeat me-1"></i>
              Antécédents Médicaux (liés à l'alimentation)
            </label>
            <div className="row">
              {medicalConditionsList.map((condition) => (
                <div className="col-md-6 col-lg-4" key={condition}>
                  <div className="form-check">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      value={condition}
                      checked={medicalConditions.includes(condition)}
                      onChange={handleMedicalConditionChange}
                      disabled={loading}
                      id={`medical-${condition}`}
                    />
                    <label className="form-check-label" htmlFor={`medical-${condition}`}>
                      {condition}
                    </label>
                  </div>
                </div>
              ))}
              <div className="col-md-6 col-lg-4">
                <div className="form-check">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    value="Autres"
                    checked={medicalConditions.includes("Autres")}
                    onChange={handleMedicalConditionChange}
                    disabled={loading}
                    id="medical-autres"
                  />
                  <label className="form-check-label" htmlFor="medical-autres">
                    Autres
                  </label>
                </div>
              </div>
            </div>
            {medicalConditions.includes("Autres") && (
              <input
                type="text"
                className="form-control mt-2"
                placeholder="Veuillez spécifier d'autres conditions"
                value={otherMedicalCondition}
                onChange={(e) => setOtherMedicalCondition(e.target.value)}
                required={medicalConditions.includes("Autres")}
                disabled={loading}
              />
            )}
          </div>

          <div className="form-group">
            <label className="form-label">
              <i className="fas fa-users me-1"></i>
              Rôle dans la famille *
            </label>
            <div className="row">
              {familyRoles.map((roleOption) => (
                <div className="col-md-6 col-lg-4" key={roleOption}>
                  <div className="form-check">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      value={roleOption}
                      checked={role.includes(roleOption)}
                      onChange={handleRoleChange}
                      disabled={loading}
                      id={`role-${roleOption}`}
                    />
                    <label className="form-check-label" htmlFor={`role-${roleOption}`}>
                      {roleOption}
                    </label>
                  </div>
                </div>
              ))}
              <div className="col-md-6 col-lg-4">
                <div className="form-check">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    value="Autres"
                    checked={role.includes("Autres")}
                    onChange={handleRoleChange}
                    disabled={loading}
                    id="role-autres"
                  />
                  <label className="form-check-label" htmlFor="role-autres">
                    Autres
                  </label>
                </div>
              </div>
            </div>
            {role.includes("Autres") && (
              <input
                type="text"
                className="form-control mt-2"
                placeholder="Veuillez spécifier le rôle"
                value={otherRole}
                onChange={(e) => setOtherRole(e.target.value)}
                required={role.includes("Autres")}
                disabled={loading}
              />
            )}
            {errors.role && <div className="text-danger small mt-1">{errors.role}</div>}
          </div>

          <div className="form-group">
            <label htmlFor="memberEmail" className="form-label">
              <i className="fas fa-envelope me-1"></i>
              Email {isEmailDisabled ? "(désactivé si âge inférieur à 5 ans)" : "*"}
            </label>
            <input
              type="email"
              className={`form-control ${errors.email ? "is-invalid" : email && !isEmailDisabled ? "is-valid" : ""}`}
              id="memberEmail"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={isEmailDisabled || loading}
              required={!isEmailDisabled}
              placeholder="Email du membre"
            />
            {errors.email && <div className="invalid-feedback">{errors.email}</div>}
          </div>

          <div className="form-group">
            <label htmlFor="memberProfilePic" className="form-label">
              <i className="fas fa-camera me-1"></i>
              Photo de Profil (optionnel)
            </label>
            <div className="d-flex align-items-center gap-3">
              <input
                type="file"
                className="form-control"
                id="memberProfilePic"
                accept="image/*"
                onChange={handleProfilePicChange}
                disabled={loading}
              />
              {profilePicPreview && (
                <img src={profilePicPreview || "/placeholder.svg"} alt="Aperçu" className="profile-pic-preview" />
              )}
            </div>
          </div>

          <div className="d-flex gap-3 mt-4">
            <button type="submit" className="btn btn-success flex-fill" disabled={loading}>
              {loading ? (
                <>
                  <span className="loading-spinner me-2"></span>
                  Sauvegarde...
                </>
              ) : (
                <>
                  <i className="fas fa-save me-2"></i>
                  {isNew ? "Ajouter le Membre" : "Sauvegarder les Modifications"}
                </>
              )}
            </button>

            {onCancel && (
              <button type="button" className="btn btn-secondary" onClick={onCancel} disabled={loading}>
                <i className="fas fa-times me-2"></i>
                Annuler
              </button>
            )}

            {!isNew && onDelete && (
              <button type="button" className="btn btn-danger" onClick={handleDelete} disabled={loading}>
                <i className="fas fa-trash me-2"></i>
                Supprimer
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  )
}

export default FamilyMemberForm
