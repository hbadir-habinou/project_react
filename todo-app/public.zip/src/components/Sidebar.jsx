"use client"
import { useLanguage } from "../contexts/LanguageContext"

const Sidebar = ({ activeTab, setActiveTab, isCollapsed, setIsCollapsed }) => {
  const { t } = useLanguage()

  const menuItems = [
    {
      id: "overview",
      icon: "fas fa-chart-pie",
      label: t("sidebar.overview"),
      tab: "overview",
    },
    {
      id: "members",
      icon: "fas fa-users",
      label: t("sidebar.family"),
      tab: "members",
    },
    {
      id: "dishes",
      icon: "fas fa-utensils",
      label: t("sidebar.meals"),
      tab: "dishes",
    },
    {
      id: "ingredients",
      icon: "fas fa-carrot",
      label: t("sidebar.inventory"),
      tab: "ingredients",
    },
    {
      id: "planning",
      icon: "fas fa-calendar-alt",
      label: t("sidebar.planning"),
      tab: "planning",
    },
    {
      id: "shopping",
      icon: "fas fa-shopping-cart",
      label: t("sidebar.shopping"),
      tab: "shopping",
    },
    {
      id: "recipes",
      icon: "fas fa-book-open",
      label: t("sidebar.recipes"),
      tab: "recipes",
    },
    {
      id: "sharing",
      icon: "fas fa-share-alt",
      label: t("sidebar.sharing"),
      tab: "sharedRecipes",
    },
  ]

  return (
    <div className={`sidebar ${isCollapsed ? "collapsed" : ""}`}>
      <div className="sidebar-header">
        <div className="sidebar-brand">
          <i className="fas fa-utensils"></i>
          {!isCollapsed && <span>FoodPlanner</span>}
        </div>
        <button className="sidebar-toggle" onClick={() => setIsCollapsed(!isCollapsed)}>
          <i className={`fas ${isCollapsed ? "fa-chevron-right" : "fa-chevron-left"}`}></i>
        </button>
      </div>

      <nav className="sidebar-nav">
        <ul className="sidebar-menu">
          {menuItems.map((item) => (
            <li key={item.id} className="sidebar-item">
              <button
                className={`sidebar-link ${activeTab === item.tab ? "active" : ""}`}
                onClick={() => setActiveTab(item.tab)}
                title={isCollapsed ? item.label : ""}
              >
                <i className={item.icon}></i>
                {!isCollapsed && <span>{item.label}</span>}
              </button>
            </li>
          ))}
        </ul>
      </nav>

      <div className="sidebar-footer">
        <button className="sidebar-link">
          <i className="fas fa-cog"></i>
          {!isCollapsed && <span>{t("sidebar.settings")}</span>}
        </button>
        <button className="sidebar-link">
          <i className="fas fa-question-circle"></i>
          {!isCollapsed && <span>{t("sidebar.help")}</span>}
        </button>
      </div>
    </div>
  )
}

export default Sidebar
