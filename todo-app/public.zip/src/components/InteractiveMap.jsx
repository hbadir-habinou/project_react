import { useEffect, useRef } from "react";
import { Loader } from "@googlemaps/js-api-loader";

const InteractiveMap = ({ userLocation, vendors, onVendorSelect }) => {
  const mapRef = useRef(null);
  const mapInstance = useRef(null);

  useEffect(() => {
    const loader = new Loader({
      apiKey: "YOUR_GOOGLE_MAPS_API_KEY", // Remplacez par votre clé API
      version: "weekly",
      libraries: ["places"],
    });

    loader.load().then(() => {
      if (!mapRef.current || !userLocation) return;

      mapInstance.current = new window.google.maps.Map(mapRef.current, {
        center: { lat: userLocation.latitude, lng: userLocation.longitude },
        zoom: 14,
      });

      // Ajouter un marqueur pour la localisation de l'utilisateur
      new window.google.maps.Marker({
        position: { lat: userLocation.latitude, lng: userLocation.longitude },
        map: mapInstance.current,
        title: "Votre position",
        icon: {
          url: "http://maps.google.com/mapfiles/ms/icons/blue-dot.png",
        },
      });

      // Ajouter des marqueurs pour les vendeurs
      vendors.forEach((vendor) => {
        if (vendor.location) {
          const marker = new window.google.maps.Marker({
            position: { lat: vendor.location.latitude, lng: vendor.location.longitude },
            map: mapInstance.current,
            title: vendor.name,
          });

          const infoWindow = new window.google.maps.InfoWindow({
            content: `
              <div>
                <h6>${vendor.name}</h6>
                <p>${vendor.address}</p>
                <button onclick="window.selectVendor('${vendor.id}')">Sélectionner</button>
              </div>
            `,
          });

          marker.addListener("click", () => {
            infoWindow.open(mapInstance.current, marker);
          });
        }
      });

      // Fonction globale pour sélectionner un vendeur
      window.selectVendor = (vendorId) => {
        const vendor = vendors.find((v) => v.id === vendorId);
        if (vendor) onVendorSelect(vendor);
      };

      // Rechercher les marchés/supermarchés à proximité
      const service = new window.google.maps.places.PlacesService(mapInstance.current);
      service.nearbySearch(
        {
          location: { lat: userLocation.latitude, lng: userLocation.longitude },
          radius: 5000, // 5 km
          type: ["supermarket", "grocery_or_supermarket", "market"],
        },
        (results, status) => {
          if (status === window.google.maps.places.PlacesServiceStatus.OK) {
            results.forEach((place) => {
              const marker = new window.google.maps.Marker({
                position: place.geometry.location,
                map: mapInstance.current,
                title: place.name,
                icon: {
                  url: "http://maps.google.com/mapfiles/ms/icons/green-dot.png",
                },
              });

              const infoWindow = new window.google.maps.InfoWindow({
                content: `
                  <div>
                    <h6>${place.name}</h6>
                    <p>${place.vicinity}</p>
                    <a href="https://www.google.com/maps/dir/?api=1&destination=${place.geometry.location.lat()},${place.geometry.location.lng()}" target="_blank">Itinéraire</a>
                  </div>
                `,
              });

              marker.addListener("click", () => {
                infoWindow.open(mapInstance.current, marker);
              });
            });
          }
        }
      );
    });

    return () => {
      window.selectVendor = undefined;
    };
  }, [userLocation, vendors, onVendorSelect]);

  return (
    <div
      ref={mapRef}
      style={{ height: "400px", width: "100%", borderRadius: "15px", overflow: "hidden" }}
    ></div>
  );
};

export default InteractiveMap;