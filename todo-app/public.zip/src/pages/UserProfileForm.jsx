"use client"

import { useState, useEffect } from "react"
import { auth, db } from "../firebase"
import { doc, setDoc } from "firebase/firestore"
import { useNavigate } from "react-router-dom"

const UserProfileForm = ({ setHasCompletedProfile }) => {
  const navigate = useNavigate()
  const [fullName, setFullName] = useState("")
  const [age, setAge] = useState("")
  const [gender, setGender] = useState("")
  const [medicalConditions, setMedicalConditions] = useState([])
  const [otherMedicalCondition, setOtherMedicalCondition] = useState("")
  const [role, setRole] = useState([])
  const [otherRole, setOtherRole] = useState("")
  const [profilePic, setProfilePic] = useState(null)
  const [profilePicPreview, setProfilePicPreview] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  const medicalConditionsList = [
    "Diabète",
    "Hypertension",
    "Maladie cœliaque",
    "Allergie aux arachides",
    "Intolérance au lactose",
    "Végétarien",
    "Végétalien",
    "Aucun",
  ]

  const familyRoles = ["Mère", "Père", "Enfant", "Grand-parent"]

  useEffect(() => {
    if (auth.currentUser) {
      // Pré-remplir l'email si l'utilisateur est connecté
    } else {
      navigate("/login")
    }
  }, [navigate])

  const handleMedicalConditionChange = (e) => {
    const { value, checked } = e.target
    if (checked) {
      setMedicalConditions([...medicalConditions, value])
    } else {
      setMedicalConditions(medicalConditions.filter((condition) => condition !== value))
    }
  }

  const handleRoleChange = (e) => {
    const { value, checked } = e.target
    if (checked) {
      setRole([...role, value])
    } else {
      setRole(role.filter((r) => r !== value))
    }
  }

  const handleProfilePicChange = (e) => {
    const file = e.target.files[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setProfilePic(reader.result)
        setProfilePicPreview(reader.result)
      }
      reader.readAsDataURL(file)
    } else {
      setProfilePic(null)
      setProfilePicPreview("")
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    if (!auth.currentUser) {
      setError("Aucun utilisateur authentifié. Veuillez vous connecter.")
      setLoading(false)
      return
    }

    const userProfileData = {
      fullName,
      age: Number.parseInt(age),
      gender,
      email: auth.currentUser.email,
      medicalConditions: medicalConditions.includes("Autres")
        ? [...medicalConditions.filter((c) => c !== "Autres"), otherMedicalCondition]
        : medicalConditions,
      role: role.includes("Autres") ? [...role.filter((r) => r !== "Autres"), otherRole] : role,
      profilePic: profilePic,
      completedProfile: true,
      createdAt: new Date(),
      uid: auth.currentUser.uid,
    }

    try {
      await setDoc(doc(db, "users", auth.currentUser.uid), userProfileData, { merge: true })
      setHasCompletedProfile(true)
      navigate("/setup-family")
    } catch (err) {
      console.error("Erreur lors de l'enregistrement du profil: ", err)
      setError("Échec de l'enregistrement du profil. Veuillez réessayer.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container my-5">
      <div className="row justify-content-center">
        <div className="col-lg-8">
          <div className="card glass-effect fade-in">
            <div className="card-header text-center">
              <h2 className="mb-0">
                <i className="fas fa-user-circle me-2 text-primary"></i>
                Votre Profil Principal
              </h2>
            </div>
            <div className="card-body">
              {error && (
                <div className="alert alert-danger d-flex align-items-center" role="alert">
                  <i className="fas fa-exclamation-triangle me-2"></i>
                  {error}
                </div>
              )}

              <form onSubmit={handleSubmit}>
                <div className="row">
                  <div className="col-md-6">
                    <div className="form-group">
                      <label htmlFor="fullName" className="form-label">
                        <i className="fas fa-user me-1"></i>
                        Nom Complet *
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        id="fullName"
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        required
                        disabled={loading}
                      />
                    </div>
                  </div>

                  <div className="col-md-6">
                    <div className="form-group">
                      <label htmlFor="age" className="form-label">
                        <i className="fas fa-birthday-cake me-1"></i>
                        Âge *
                      </label>
                      <input
                        type="number"
                        className="form-control"
                        id="age"
                        value={age}
                        onChange={(e) => setAge(e.target.value)}
                        min="0"
                        required
                        disabled={loading}
                      />
                    </div>
                  </div>
                </div>

                <div className="form-group">
                  <label className="form-label">
                    <i className="fas fa-venus-mars me-1"></i>
                    Sexe *
                  </label>
                  <div className="d-flex gap-4 mt-2">
                    <div className="form-check">
                      <input
                        className="form-check-input"
                        type="radio"
                        value="Homme"
                        checked={gender === "Homme"}
                        onChange={(e) => setGender(e.target.value)}
                        required
                        disabled={loading}
                        id="homme"
                      />
                      <label className="form-check-label" htmlFor="homme">
                        <i className="fas fa-mars me-1"></i>
                        Homme
                      </label>
                    </div>
                    <div className="form-check">
                      <input
                        className="form-check-input"
                        type="radio"
                        value="Femme"
                        checked={gender === "Femme"}
                        onChange={(e) => setGender(e.target.value)}
                        required
                        disabled={loading}
                        id="femme"
                      />
                      <label className="form-check-label" htmlFor="femme">
                        <i className="fas fa-venus me-1"></i>
                        Femme
                      </label>
                    </div>
                    <div className="form-check">
                      <input
                        className="form-check-input"
                        type="radio"
                        value="Autre"
                        checked={gender === "Autre"}
                        onChange={(e) => setGender(e.target.value)}
                        disabled={loading}
                        id="autre"
                      />
                      <label className="form-check-label" htmlFor="autre">
                        <i className="fas fa-genderless me-1"></i>
                        Autre
                      </label>
                    </div>
                  </div>
                </div>

                <div className="form-group">
                  <label className="form-label">
                    <i className="fas fa-heartbeat me-1"></i>
                    Antécédents Médicaux (liés à l'alimentation)
                  </label>
                  <div className="row">
                    {medicalConditionsList.map((condition) => (
                      <div className="col-md-6 col-lg-4" key={condition}>
                        <div className="form-check">
                          <input
                            className="form-check-input"
                            type="checkbox"
                            value={condition}
                            checked={medicalConditions.includes(condition)}
                            onChange={handleMedicalConditionChange}
                            disabled={loading}
                            id={`medical-${condition}`}
                          />
                          <label className="form-check-label" htmlFor={`medical-${condition}`}>
                            {condition}
                          </label>
                        </div>
                      </div>
                    ))}
                    <div className="col-md-6 col-lg-4">
                      <div className="form-check">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          value="Autres"
                          checked={medicalConditions.includes("Autres")}
                          onChange={handleMedicalConditionChange}
                          disabled={loading}
                          id="medical-autres"
                        />
                        <label className="form-check-label" htmlFor="medical-autres">
                          Autres
                        </label>
                      </div>
                    </div>
                  </div>
                  {medicalConditions.includes("Autres") && (
                    <input
                      type="text"
                      className="form-control mt-2"
                      placeholder="Veuillez spécifier d'autres conditions"
                      value={otherMedicalCondition}
                      onChange={(e) => setOtherMedicalCondition(e.target.value)}
                      required={medicalConditions.includes("Autres")}
                      disabled={loading}
                    />
                  )}
                </div>

                <div className="form-group">
                  <label className="form-label">
                    <i className="fas fa-users me-1"></i>
                    Votre Rôle dans la famille
                  </label>
                  <div className="row">
                    {familyRoles.map((roleOption) => (
                      <div className="col-md-6 col-lg-3" key={roleOption}>
                        <div className="form-check">
                          <input
                            className="form-check-input"
                            type="checkbox"
                            value={roleOption}
                            checked={role.includes(roleOption)}
                            onChange={handleRoleChange}
                            disabled={loading}
                            id={`role-${roleOption}`}
                          />
                          <label className="form-check-label" htmlFor={`role-${roleOption}`}>
                            {roleOption}
                          </label>
                        </div>
                      </div>
                    ))}
                    <div className="col-md-6 col-lg-3">
                      <div className="form-check">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          value="Autres"
                          checked={role.includes("Autres")}
                          onChange={handleRoleChange}
                          disabled={loading}
                          id="role-autres"
                        />
                        <label className="form-check-label" htmlFor="role-autres">
                          Autres
                        </label>
                      </div>
                    </div>
                  </div>
                  {role.includes("Autres") && (
                    <input
                      type="text"
                      className="form-control mt-2"
                      placeholder="Veuillez spécifier votre rôle"
                      value={otherRole}
                      onChange={(e) => setOtherRole(e.target.value)}
                      required={role.includes("Autres")}
                      disabled={loading}
                    />
                  )}
                </div>

                <div className="form-group">
                  <label htmlFor="profilePic" className="form-label">
                    <i className="fas fa-camera me-1"></i>
                    Photo de Profil (optionnel)
                  </label>
                  <div className="d-flex align-items-center gap-3">
                    <input
                      type="file"
                      className="form-control"
                      id="profilePic"
                      accept="image/*"
                      onChange={handleProfilePicChange}
                      disabled={loading}
                    />
                    {profilePicPreview && (
                      <img src={profilePicPreview || "/placeholder.svg"} alt="Aperçu" className="profile-pic-preview" />
                    )}
                  </div>
                </div>

                <div className="d-grid">
                  <button type="submit" className="btn btn-primary btn-lg" disabled={loading}>
                    {loading ? (
                      <>
                        <span className="loading-spinner me-2"></span>
                        Enregistrement...
                      </>
                    ) : (
                      <>
                        <i className="fas fa-save me-2"></i>
                        Enregistrer et Continuer
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default UserProfileForm
