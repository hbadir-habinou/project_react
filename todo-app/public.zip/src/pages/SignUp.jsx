"use client"

import { useState } from "react"
import { Link } from "react-router-dom"
import { auth, googleProvider, db } from "../firebase"
import { createUserWithEmailAndPassword, signInWithPopup, signInAnonymously } from "firebase/auth"
import { useNavigate } from "react-router-dom"
import { doc, setDoc, getDoc, collection, getDocs } from "firebase/firestore"
import { useLanguage } from "../contexts/LanguageContext"
import ProfileSelection from "./ProfileSelection"

const SignUp = ({ setIsAuth }) => {
  const navigate = useNavigate()
  const { t } = useLanguage()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [familyCode, setFamilyCode] = useState("")
  const [showFamilyCodeInput, setShowFamilyCodeInput] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [members, setMembers] = useState([])
  const [showProfileSelection, setShowProfileSelection] = useState(false)
  const [currentUser, setCurrentUser] = useState(null)
  const [isGuestMode, setIsGuestMode] = useState(false)

  const fetchFamilyMembers = async (familyCode) => {
    try {
      const membersCollection = collection(db, "families", familyCode, "members")
      const membersSnapshot = await getDocs(membersCollection)
      const membersList = membersSnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }))
      setMembers(membersList)
      console.log("Membres récupérés:", membersList)
      return membersList.length > 0
    } catch (err) {
      setError("Erreur lors de la récupération des membres : " + err.message)
      return false
    }
  }

  // Fonction pour l'accès direct avec code familial
  const handleFamilyCodeAccess = async () => {
    if (!familyCode.trim()) {
      setError("Veuillez entrer un code familial")
      return
    }

    setLoading(true)
    setError("")

    try {
      // Vérifier si la famille existe
      const familyDoc = await getDoc(doc(db, "families", familyCode))
      if (!familyDoc.exists()) {
        setError("Code familial invalide")
        setLoading(false)
        return
      }

      // Récupérer les membres automatiquement
      const hasMembers = await fetchFamilyMembers(familyCode)
      if (hasMembers) {
        // Créer un utilisateur anonyme pour l'accès invité
        const userCredential = await signInAnonymously(auth)
        setCurrentUser(userCredential.user)
        setIsAuth(true)
        setIsGuestMode(true)
        setShowProfileSelection(true)
        setLoading(false)
        return
      }

      setError("Aucun membre trouvé dans cette famille")
      setLoading(false)
    } catch (err) {
      setError("Erreur lors de l'accès à la famille : " + err.message)
      setLoading(false)
    }
  }

  const handleSuccessfulAuth = async (user) => {
    setIsAuth(true)
    setCurrentUser(user)

    // Si l'utilisateur a coché "Accéder avec un code famille", traiter comme mode invité
    if (showFamilyCodeInput && familyCode.trim()) {
      try {
        // Vérifier si la famille existe
        const familyDoc = await getDoc(doc(db, "families", familyCode))
        if (!familyDoc.exists()) {
          setError("Code familial invalide")
          setLoading(false)
          return
        }

        // Récupérer les membres automatiquement
        const hasMembers = await fetchFamilyMembers(familyCode)
        if (hasMembers) {
          setShowProfileSelection(true)
          setLoading(false)
          return
        }

        setError("Aucun membre trouvé dans cette famille")
        setLoading(false)
        return
      } catch (err) {
        setError("Erreur lors de la connexion à la famille : " + err.message)
        setLoading(false)
        return
      }
    } else {
      // Inscription normale sans code famille
      navigate("/complete-profile")
    }
  }

  const handleProfileSelect = async (member) => {
    if (!currentUser) return

    try {
      setLoading(true)

      if (isGuestMode) {
        // Mode invité - accès en lecture seule
        try {
          // Récupérer directement les informations de la famille
          const familyDoc = await getDoc(doc(db, "families", familyCode))

          if (!familyDoc.exists()) {
            throw new Error("Famille non trouvée")
          }

          const familyData = familyDoc.data()
          const adminUserId = familyData.adminId || familyData.createdBy

          if (!adminUserId) {
            throw new Error("Impossible de déterminer l'administrateur de la famille")
          }

          const guestUserData = {
            email: `guest_${Date.now()}@family.local`,
            familyCode: familyCode,
            fullName: member.fullName,
            age: member.age,
            gender: member.gender,
            role: "guest",
            medicalConditions: member.medicalConditions || [],
            profilePic: member.profilePic || null,
            completedProfile: true,
            selectedMemberId: member.id,
            isReadOnly: true,
            isGuest: true,
            adminUserId: adminUserId,
          }

          // Créer le profil utilisateur temporaire pour l'invité
          const userDocRef = doc(db, "users", currentUser.uid)
          await setDoc(userDocRef, guestUserData, { merge: true })

          // Stocker également dans le localStorage pour la persistance
          localStorage.setItem("guestUserData", JSON.stringify(guestUserData))
          localStorage.setItem("guestFamilyCode", familyCode)
          localStorage.setItem("guestAdminUserId", adminUserId)
        } catch (err) {
          setError("Erreur lors de la configuration du mode invité : " + err.message)
          setLoading(false)
          return
        }
      } else {
        // Mode normal avec authentification - reste inchangé
        const userDocRef = doc(db, "users", currentUser.uid)
        await setDoc(
          userDocRef,
          {
            email: currentUser.email,
            familyCode: familyCode,
            fullName: member.fullName,
            age: member.age,
            gender: member.gender,
            role: member.role || "member",
            medicalConditions: member.medicalConditions || [],
            profilePic: member.profilePic || null,
            completedProfile: true,
            selectedMemberId: member.id,
            isReadOnly: member.role !== "admin",
          },
          { merge: true },
        )

        // Mettre à jour le membre dans la famille avec l'ID utilisateur actuel
        await setDoc(doc(db, "families", familyCode, "members", currentUser.uid), {
          ...member,
          email: currentUser.email,
          userId: currentUser.uid,
          lastLogin: new Date(),
        })
      }

      setShowProfileSelection(false)
      setLoading(false)

      // Redirection avec un petit délai pour l'effet visuel
      setTimeout(() => {
        navigate("/family-dashboard")
      }, 500)
    } catch (err) {
      setError("Erreur lors de la sélection du profil : " + err.message)
      setLoading(false)
    }
  }

  const signUpWithEmailAndPassword = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password)
      await handleSuccessfulAuth(userCredential.user)
    } catch (error) {
      setError("Erreur d'inscription : " + error.message)
      console.log(error)
    } finally {
      if (!showFamilyCodeInput) {
        setLoading(false)
      }
    }
  }

  const signUpWithGoogle = async () => {
    setLoading(true)
    setError("")

    try {
      const userCredential = await signInWithPopup(auth, googleProvider)
      await handleSuccessfulAuth(userCredential.user)
    } catch (error) {
      setError("Erreur d'inscription Google : " + error.message)
      console.log(error)
    } finally {
      if (!showFamilyCodeInput) {
        setLoading(false)
      }
    }
  }

  if (showProfileSelection) {
    return (
      <ProfileSelection
        members={members}
        onSelect={handleProfileSelect}
        onBack={() => {
          setShowProfileSelection(false)
          setIsGuestMode(false)
          setLoading(false)
        }}
        isGuestMode={isGuestMode}
      />
    )
  }

  return (
    <div className="container my-5">
      <div className="row justify-content-center">
        <div className="col-md-6 col-lg-5">
          <div className="card glass-effect fade-in">
            <div className="card-header text-center">
              <h2 className="mb-0">
                <i className="fas fa-user-plus me-2 text-primary"></i>
                Inscription
              </h2>
            </div>
            <div className="card-body">
              {error && (
                <div className="alert alert-danger d-flex align-items-center" role="alert">
                  <i className="fas fa-exclamation-triangle me-2"></i>
                  {error}
                </div>
              )}

              <div className="form-check mb-3">
                <input
                  type="checkbox"
                  className="form-check-input"
                  id="joinFamily"
                  checked={showFamilyCodeInput}
                  onChange={(e) => setShowFamilyCodeInput(e.target.checked)}
                />
                <label className="form-check-label" htmlFor="joinFamily">
                  Accéder avec un code famille (mode invité)
                </label>
              </div>

              {showFamilyCodeInput ? (
                // Mode code familial - accès direct
                <div>
                  <div className="alert alert-info">
                    <i className="fas fa-info-circle me-2"></i>
                    Mode accès familial : Entrez simplement le code pour accéder au dashboard en lecture seule
                  </div>

                  <div className="form-group mb-3">
                    <label htmlFor="familyCode" className="form-label">
                      <i className="fas fa-users me-1"></i>
                      Code Familial
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      id="familyCode"
                      placeholder="Entrez le code familial..."
                      value={familyCode}
                      onChange={(e) => setFamilyCode(e.target.value.toUpperCase())}
                      disabled={loading}
                      required
                    />
                    <small className="text-muted">
                      Avec ce code, vous pourrez sélectionner votre profil et accéder au dashboard familial.
                    </small>
                  </div>

                  <button
                    type="button"
                    className="btn btn-success w-100 mb-3"
                    onClick={handleFamilyCodeAccess}
                    disabled={loading || !familyCode.trim()}
                  >
                    {loading ? (
                      <>
                        <span className="loading-spinner me-2"></span>
                        Accès en cours...
                      </>
                    ) : (
                      <>
                        <i className="fas fa-users me-2"></i>
                        Accéder à la famille
                      </>
                    )}
                  </button>
                </div>
              ) : (
                // Mode inscription normale
                <form onSubmit={signUpWithEmailAndPassword}>
                  <div className="form-group">
                    <label htmlFor="email" className="form-label">
                      <i className="fas fa-envelope me-1"></i>
                      Email
                    </label>
                    <input
                      type="email"
                      className="form-control"
                      id="email"
                      required
                      placeholder="Votre Email..."
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      disabled={loading}
                    />
                  </div>

                  <div className="form-group">
                    <label htmlFor="password" className="form-label">
                      <i className="fas fa-lock me-1"></i>
                      Mot de passe
                    </label>
                    <input
                      type="password"
                      className="form-control"
                      id="password"
                      required
                      placeholder="Votre Mot de Passe..."
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      disabled={loading}
                    />
                  </div>

                  <small className="form-text text-muted mb-3 d-block">
                    Le mot de passe doit contenir au moins 6 caractères.
                  </small>

                  <button type="submit" className="btn btn-primary w-100 mb-3" disabled={loading}>
                    {loading ? (
                      <>
                        <span className="loading-spinner me-2"></span>
                        Inscription...
                      </>
                    ) : (
                      <>
                        <i className="fas fa-user-plus me-2"></i>
                        S'inscrire
                      </>
                    )}
                  </button>

                  <button className="btn sign-in-with-google w-100 mb-3" onClick={signUpWithGoogle} disabled={loading}>
                    <i className="fab fa-google me-2"></i>
                    S'inscrire avec Google
                  </button>
                </form>
              )}

              <p className="text-center mb-0">
                {showFamilyCodeInput ? (
                  <>
                    Vous voulez créer un compte ?
                    <Link
                      to="/signup"
                      className="text-decoration-none ms-1"
                      onClick={() => setShowFamilyCodeInput(false)}
                    >
                      Inscription normale
                    </Link>
                  </>
                ) : (
                  <>
                    Vous avez déjà un compte ?
                    <Link to="/login" className="text-decoration-none ms-1">
                      Se connecter
                    </Link>
                  </>
                )}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default SignUp
