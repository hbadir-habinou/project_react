"use client"

import { useState, useEffect } from "react"
import { auth, db } from "../firebase"
import { collection, addDoc } from "firebase/firestore"
import { useNavigate } from "react-router-dom"
import FamilyMemberForm from "../components/FamilyMemberForm"

const FamilyMemberSetup = () => {
  const navigate = useNavigate()
  const [members, setMembers] = useState([])
  const [showNewMemberForm, setShowNewMemberForm] = useState(true)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  useEffect(() => {
    if (!auth.currentUser) {
      navigate("/login")
    }
  }, [navigate])

  const handleAddMember = async (newMemberData) => {
    setLoading(true)
    setError("")
    try {
      if (!auth.currentUser) {
        throw new Error("Aucun utilisateur authentifié.")
      }
      const membersCollectionRef = collection(db, "users", auth.currentUser.uid, "familyMembers")
      const docRef = await addDoc(membersCollectionRef, {
        ...newMemberData,
        ownerId: auth.currentUser.uid,
        createdAt: new Date(),
      })
      setMembers((prevMembers) => [...prevMembers, { ...newMemberData, id: docRef.id }])
      setShowNewMemberForm(false)
    } catch (err) {
      console.error("Erreur détaillée lors de l'ajout du membre : ", err)
      setError(`Échec de l'ajout du membre : ${err.message}`)
    } finally {
      setLoading(false)
    }
  }

  const handleContinue = () => {
    navigate("/family-dashboard")
  }

  return (
    <div className="container my-5">
      <div className="row justify-content-center">
        <div className="col-lg-10">
          <div className="card glass-effect fade-in">
            <div className="card-header text-center">
              <h2 className="mb-0">
                <i className="fas fa-users me-2 text-primary"></i>
                Configuration des Membres de la Famille
              </h2>
            </div>
            <div className="card-body">
              {error && (
                <div className="alert alert-danger d-flex align-items-center" role="alert">
                  <i className="fas fa-exclamation-triangle me-2"></i>
                  {error}
                </div>
              )}

              {members.length > 0 && (
                <div className="mb-4">
                  <h4 className="text-center mb-3">
                    <i className="fas fa-check-circle text-success me-2"></i>
                    Membres ajoutés
                  </h4>
                  <div className="row">
                    {members.map((member, index) => (
                      <div key={index} className="col-md-6 col-lg-4 mb-3">
                        <div className="card h-100 slide-in">
                          <div className="card-body text-center">
                            {member.profilePic && (
                              <img
                                src={member.profilePic || "/placeholder.svg"}
                                alt={member.fullName}
                                className="profile-pic-preview mb-3"
                              />
                            )}
                            <h5 className="card-title">{member.fullName}</h5>
                            <p className="card-text">
                              <i className="fas fa-birthday-cake me-1"></i>
                              {member.age} ans
                            </p>
                            <p className="card-text">
                              <i className="fas fa-users me-1"></i>
                              {member.role.join(", ")}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {showNewMemberForm ? (
                <FamilyMemberForm
                  member={{}}
                  onSave={handleAddMember}
                  onCancel={() => setShowNewMemberForm(false)}
                  isNew={true}
                />
              ) : (
                <div className="text-center">
                  <div className="d-flex gap-3 justify-content-center">
                    <button
                      className="btn btn-success btn-lg"
                      onClick={() => setShowNewMemberForm(true)}
                      disabled={loading}
                    >
                      <i className="fas fa-user-plus me-2"></i>
                      Ajouter un autre membre
                    </button>
                    <button className="btn btn-primary btn-lg" onClick={handleContinue} disabled={loading}>
                      {loading ? (
                        <>
                          <span className="loading-spinner me-2"></span>
                          Chargement...
                        </>
                      ) : (
                        <>
                          <i className="fas fa-arrow-right me-2"></i>
                          Continuer vers le Tableau de Bord
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default FamilyMemberSetup
