"use client"

import { useLanguage } from "../contexts/LanguageContext"

const ProfileSelection = ({ members, onSelect, onBack, isGuestMode = false }) => {
  const { t } = useLanguage()

  return (
    <div
      className="profile-selection-container"
      style={{
        background: "linear-gradient(135deg, #0f0f23 0%, #1a1a2e 50%, #16213e 100%)",
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        padding: "20px",
        position: "relative",
        overflow: "hidden",
      }}
    >
      {/* Effet de particules en arrière-plan */}
      <div
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          width: "100%",
          height: "100%",
          background: `
            radial-gradient(circle at 20% 80%, rgba(120, 119, 198, 0.3) 0%, transparent 50%),
            radial-gradient(circle at 80% 20%, rgba(255, 119, 198, 0.3) 0%, transparent 50%),
            radial-gradient(circle at 40% 40%, rgba(120, 219, 255, 0.2) 0%, transparent 50%)
          `,
          zIndex: 1,
        }}
      />

      <div className="text-center mb-5" style={{ zIndex: 2, position: "relative" }}>
        <h1
          className="display-3 text-white mb-4"
          style={{
            fontWeight: 800,
            fontSize: "3.5rem",
            textShadow: "0 4px 20px rgba(0,0,0,0.8)",
            background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            backgroundClip: "text",
            letterSpacing: "-2px",
          }}
        >
          <i className="fas fa-users me-3"></i>
          Qui regarde ?
        </h1>
        <p
          className="text-white-50 mb-4"
          style={{
            fontSize: "1.3rem",
            maxWidth: "700px",
            margin: "0 auto",
            fontWeight: 300,
            lineHeight: 1.6,
          }}
        >
          {isGuestMode
            ? "Sélectionnez votre profil pour accéder au dashboard familial en mode lecture seule."
            : "Sélectionnez votre profil pour continuer votre expérience personnalisée."}
        </p>
        {isGuestMode && (
          <div
            className="alert alert-info mx-auto"
            style={{
              maxWidth: "600px",
              background: "rgba(13, 202, 240, 0.1)",
              border: "1px solid rgba(13, 202, 240, 0.3)",
              borderRadius: "15px",
              backdropFilter: "blur(10px)",
              color: "#0dcaf0",
            }}
          >
            <i className="fas fa-info-circle me-2"></i>
            Mode invité activé - Accès en lecture seule au dashboard familial
          </div>
        )}
      </div>

      <div
        className="profiles-grid"
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
          gap: "30px",
          maxWidth: "1400px",
          width: "100%",
          zIndex: 2,
          position: "relative",
          padding: "0 20px",
        }}
      >
        {members.map((member, index) => (
          <div
            key={member.id}
            className="profile-card"
            onClick={() => onSelect(member)}
            role="button"
            tabIndex={0}
            onKeyPress={(e) => e.key === "Enter" && onSelect(member)}
            style={{
              background: "rgba(255,255,255,0.05)",
              borderRadius: "20px",
              overflow: "hidden",
              cursor: "pointer",
              transition: "all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275)",
              position: "relative",
              aspectRatio: "3/4",
              display: "flex",
              flexDirection: "column",
              boxShadow: "0 8px 32px rgba(0,0,0,0.3)",
              border: "1px solid rgba(255,255,255,0.1)",
              backdropFilter: "blur(10px)",
              animationDelay: `${index * 0.1}s`,
              animation: "fadeInUp 0.6s ease-out forwards",
              opacity: 0,
              transform: "translateY(30px)",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = "scale(1.08) translateY(-10px)"
              e.currentTarget.style.boxShadow = "0 20px 60px rgba(102, 126, 234, 0.4)"
              e.currentTarget.style.border = "2px solid rgba(102, 126, 234, 0.8)"
              e.currentTarget.style.background = "rgba(102, 126, 234, 0.1)"
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = "scale(1) translateY(0)"
              e.currentTarget.style.boxShadow = "0 8px 32px rgba(0,0,0,0.3)"
              e.currentTarget.style.border = "1px solid rgba(255,255,255,0.1)"
              e.currentTarget.style.background = "rgba(255,255,255,0.05)"
            }}
          >
            {/* Image de profil */}
            <div
              style={{
                position: "relative",
                flex: 1,
                overflow: "hidden",
                borderRadius: "20px 20px 0 0",
              }}
            >
              <img
                src={
                  member.profilePic ||
                  `/placeholder.svg?height=300&width=200&text=${encodeURIComponent(member.fullName || member.name)}`
                }
                alt={member.fullName || member.name}
                style={{
                  width: "100%",
                  height: "100%",
                  objectFit: "cover",
                  transition: "transform 0.4s ease",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = "scale(1.1)"
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = "scale(1)"
                }}
              />

              {/* Overlay gradient */}
              <div
                style={{
                  position: "absolute",
                  bottom: 0,
                  left: 0,
                  right: 0,
                  height: "60%",
                  background: "linear-gradient(transparent, rgba(0,0,0,0.9))",
                  pointerEvents: "none",
                }}
              />

              {/* Badge de rôle */}
              {member.role === "admin" && (
                <div
                  style={{
                    position: "absolute",
                    top: "15px",
                    right: "15px",
                    background: "linear-gradient(135deg, #ff6b6b, #ee5a24)",
                    color: "white",
                    padding: "8px 12px",
                    borderRadius: "20px",
                    fontSize: "0.8rem",
                    fontWeight: "600",
                    boxShadow: "0 4px 15px rgba(238, 90, 36, 0.4)",
                    display: "flex",
                    alignItems: "center",
                    gap: "5px",
                  }}
                >
                  <i className="fas fa-crown"></i>
                  Admin
                </div>
              )}

              {isGuestMode && member.role !== "admin" && (
                <div
                  style={{
                    position: "absolute",
                    top: "15px",
                    right: "15px",
                    background: "linear-gradient(135deg, #0dcaf0, #0056b3)",
                    color: "white",
                    padding: "8px 12px",
                    borderRadius: "20px",
                    fontSize: "0.8rem",
                    fontWeight: "600",
                    boxShadow: "0 4px 15px rgba(13, 202, 240, 0.4)",
                    display: "flex",
                    alignItems: "center",
                    gap: "5px",
                  }}
                >
                  <i className="fas fa-eye"></i>
                  Lecture
                </div>
              )}
            </div>

            {/* Informations du profil */}
            <div
              style={{
                position: "absolute",
                bottom: 0,
                left: 0,
                right: 0,
                padding: "25px 20px 20px",
                color: "white",
                zIndex: 2,
              }}
            >
              <h3
                style={{
                  fontSize: "1.4rem",
                  fontWeight: "700",
                  margin: "0 0 8px 0",
                  textTransform: "capitalize",
                  textShadow: "0 2px 10px rgba(0,0,0,0.8)",
                  letterSpacing: "0.5px",
                }}
              >
                {member.fullName || member.name}
              </h3>

              {/* Informations supplémentaires */}
              <div style={{ fontSize: "0.9rem", opacity: 0.8, marginBottom: "10px" }}>
                {member.age && (
                  <span style={{ marginRight: "15px" }}>
                    <i className="fas fa-birthday-cake me-1"></i>
                    {member.age} ans
                  </span>
                )}
                {member.gender && (
                  <span>
                    <i className="fas fa-user me-1"></i>
                    {member.gender}
                  </span>
                )}
              </div>

              {/* Restrictions alimentaires */}
              {member.medicalConditions && member.medicalConditions.length > 0 && (
                <div style={{ display: "flex", flexWrap: "wrap", gap: "5px", marginTop: "10px" }}>
                  {member.medicalConditions.slice(0, 2).map((condition, index) => (
                    <span
                      key={index}
                      style={{
                        background: "rgba(255, 193, 7, 0.2)",
                        color: "#ffc107",
                        padding: "4px 8px",
                        borderRadius: "12px",
                        fontSize: "0.7rem",
                        fontWeight: "500",
                        border: "1px solid rgba(255, 193, 7, 0.3)",
                      }}
                    >
                      {condition}
                    </span>
                  ))}
                  {member.medicalConditions.length > 2 && (
                    <span
                      style={{
                        background: "rgba(108, 117, 125, 0.2)",
                        color: "#6c757d",
                        padding: "4px 8px",
                        borderRadius: "12px",
                        fontSize: "0.7rem",
                        fontWeight: "500",
                        border: "1px solid rgba(108, 117, 125, 0.3)",
                      }}
                    >
                      +{member.medicalConditions.length - 2}
                    </span>
                  )}
                </div>
              )}
            </div>

            {/* Effet de hover */}
            <div
              className="hover-effect"
              style={{
                position: "absolute",
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                background: "linear-gradient(135deg, rgba(102, 126, 234, 0.1), rgba(118, 75, 162, 0.1))",
                opacity: 0,
                transition: "opacity 0.3s ease",
                borderRadius: "20px",
                pointerEvents: "none",
              }}
            />
          </div>
        ))}
      </div>

      {/* Bouton de retour */}
      <div className="text-center mt-5" style={{ zIndex: 2, position: "relative" }}>
        <button
          className="btn btn-outline-light btn-lg"
          onClick={onBack}
          style={{
            borderRadius: "50px",
            padding: "15px 40px",
            fontSize: "1.1rem",
            fontWeight: "600",
            transition: "all 0.3s ease",
            border: "2px solid rgba(255,255,255,0.3)",
            background: "rgba(255,255,255,0.05)",
            backdropFilter: "blur(10px)",
            letterSpacing: "0.5px",
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.background = "rgba(255,255,255,0.15)"
            e.currentTarget.style.transform = "scale(1.05)"
            e.currentTarget.style.boxShadow = "0 10px 30px rgba(255,255,255,0.2)"
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.background = "rgba(255,255,255,0.05)"
            e.currentTarget.style.transform = "scale(1)"
            e.currentTarget.style.boxShadow = "none"
          }}
        >
          <i className="fas fa-arrow-left me-2"></i>
          Retour
        </button>
      </div>

      <style jsx>{`
        @keyframes fadeInUp {
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .profile-card:hover .hover-effect {
          opacity: 1;
        }

        .profiles-grid {
          animation: slideIn 0.8s ease-out;
        }

        @keyframes slideIn {
          from {
            opacity: 0;
            transform: translateY(50px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        /* Responsive design */
        @media (max-width: 768px) {
          .profiles-grid {
            grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
            gap: 20px;
          }
        }

        @media (max-width: 480px) {
          .profiles-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
          }
        }
      `}</style>
    </div>
  )
}

export default ProfileSelection
