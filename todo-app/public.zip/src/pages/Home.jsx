"use client"

import { useEffect } from "react"
import { auth, db } from "../firebase"
import { doc, getDoc } from "firebase/firestore"
import { useNavigate } from "react-router-dom"

const Home = (props) => {
  const navigate = useNavigate()

  useEffect(() => {
    const checkUserProfile = async () => {
      if (props.isAuth) {
        const userDocRef = doc(db, "users", auth.currentUser.uid)
        const userDocSnap = await getDoc(userDocRef)

        if (!userDocSnap.exists() || !userDocSnap.data().completedProfile) {
          navigate("/complete-profile")
        } else {
          navigate("/family-dashboard")
        }
      } else {
        navigate("/signup")
      }
    }

    const timer = setTimeout(() => {
      checkUserProfile()
    }, 500)

    return () => clearTimeout(timer)
  }, [props.isAuth, navigate])

  return (
    <div className="container-fluid vh-100 d-flex align-items-center justify-content-center">
      <div className="text-center text-white fade-in">
        <div className="mb-4">
          <i className="fas fa-utensils fa-5x mb-3 text-primary"></i>
          <h1 className="display-4 fw-bold mb-3">FoodPlanner</h1>
          <p className="lead">Planification de repas familiale moderne et intuitive</p>
        </div>
        <div className="spinner-border text-light" role="status">
          <span className="visually-hidden">Chargement...</span>
        </div>
        <p className="mt-3">Chargement de votre espace familial...</p>
      </div>
    </div>
  )
}

export default Home
