importScripts('https://www.gstatic.com/firebasejs/8.10.0/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/8.10.0/firebase-messaging.js');

// Remplacez avec votre propre configuration Firebase
const firebaseConfig = {
  apiKey: "AIzaSyCDLWSJzeHDztUxUobZBkEIMSrMfLdidRE",
  authDomain: "todo-web-a57a0.firebaseapp.com",
  projectId: "todo-web-a57a0",
  storageBucket: "todo-web-a57a0.firebasestorage.app",
  messagingSenderId: "271944674192",
  appId: "1:271944674192:web:dcaeb44fabce6af407a115",
  measurementId: "G-16DHRLB31K",
};

firebase.initializeApp(firebaseConfig);

const messaging = firebase.messaging();

messaging.onBackgroundMessage(function(payload) {
  console.log('[firebase-messaging-sw.js] Received background message ', payload);
  // Customize notification here
  const notificationTitle = payload.notification.title;
  const notificationOptions = {
    body: payload.notification.body,
    icon: '/firebase-logo.png' // Assurez-vous d'avoir une icône dans votre dossier public
  };

  self.registration.showNotification(notificationTitle,
    notificationOptions);
});

// Facultatif: Pour la mise en cache (si vous utilisez Workbox ou d'autres stratégies de PWA)
// self.addEventListener('install', event => {
//   self.skipWaiting();
// });
//
// self.addEventListener('activate', event => {
//   clients.claim();
// });